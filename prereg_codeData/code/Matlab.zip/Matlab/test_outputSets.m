EEG = pop_loadset('/data/p_02453/raw_eeg/pilot/raw-data-sets/01-output/hp0.50_Amp250/05-processed/01_processed_101.set')

%chaninfo12= load('-mat','/data/p_02453/raw_eeg/pilot/raw-data-sets/01-output/01-intermediate_processing/channelInfo_12.mat')
